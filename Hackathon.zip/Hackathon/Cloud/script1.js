// Toggle mobile navigation 
function toggleNav() {
    const nav = document.getElementById("navbar");
    nav.classList.toggle("open"); 
  }
  
  // Dynamic item rendering 
  function renderItems(items) {
    const container = document.getElementById("item-list");
    
    items.forEach(item => {
      const card = createItemCard(item);
      container.appendChild(card);
    })
  }
  
  // Form validation
  function validateForm(event) {
    if(document.myForm.name.value == "") {
      alert("Name must be filled out");
      return false;
    } 
  }